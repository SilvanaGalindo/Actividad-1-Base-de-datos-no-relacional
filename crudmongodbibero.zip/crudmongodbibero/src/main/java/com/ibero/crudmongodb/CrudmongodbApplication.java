package com.ibero.crudmongodb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudmongodbApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudmongodbApplication.class, args);
	}

}
